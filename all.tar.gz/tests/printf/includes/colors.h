#ifndef COLORS_H
# define COLORS_H

#define RED   "\033[0;31m"
#define GREEN "\033[0;32m"
#define YELLOW "\033[0;33m"
#define NONE  "\033[0m"

#endif

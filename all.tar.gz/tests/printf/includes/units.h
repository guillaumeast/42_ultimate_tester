#ifndef UNITS_H
# define UNITS_H

void	test_basic(void);
void	test_c(void);
void	test_d(void);
void	test_i(void);
void	test_p(void);
void	test_s(void);
void	test_u(void);
void	test_x_low(void);
void	test_x_upp(void);

#endif
